#include <gtk/gtk.h>


void
on_cbActive_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
