/**************************************************************************
*                                                                         *
* RFDump                                                                  * 
* Copyright (c) 2005 DN-Systems GmbH                                      *
*                                                                         *
***************************************************************************/

#include <stdio.h>
#include <expat.h>

#include "tagtypes.h"

#define BUFFSIZE 8192
#define TRUE 1
#define FALSE 0

char buff[BUFFSIZE];
int depth;
struct RFIDTagType *tmpTagType;
struct RFIDTagType **tmpTagTypes;
char element[255];
int idx;

static void XMLCALL start(void *data, const char *el, const char **attr) {

  int i;

  //for (i = 0; i < depth; i++)
    //printf("  ");

  //printf("el:%s (%d)", el, depth);

  strcpy(element, el);

  for (i = 0; attr[i]; i += 2) {

    //printf(" %s='%s'", attr[i], attr[i+1]);

    if (!strcmp(attr[i], "id")) {

      tmpTagType = (struct RFIDTagType*)malloc(sizeof(struct RFIDTagType));
      tmpTagTypes[idx] = tmpTagType;
      idx++;
      strcpy(tmpTagType->tagTypeID, attr[i+1]);
      strcpy(tmpTagType->tagTypeName, "");
      strcpy(tmpTagType->tagManufacturerName, "");
      tmpTagType->pageSize = 0;
      tmpTagType->memSize = 0;
    }
  }

  //printf("\n");
  depth++;
}

static void XMLCALL content(void *data, const char *s, int len) {

  if (len > 0) {

    char *textinfo = malloc(len+1);
    strncpy(textinfo, s, len);
    textinfo[len] = '\0';

    // strip white spaces

    int strip = 1;
    char c;

    while (strip) {
      c = textinfo[strlen(textinfo)-1];
      if (c == ' ' || c == '\t' || c == '\n') {
        textinfo[strlen(textinfo)-1] = '\0';
      } else {
        strip = 0;
      }
    }
    
    if (strlen(textinfo)>0) {

      //printf("text:'%s' (%d)\n", textinfo, depth);

      if (depth==3) {
        if (!strcmp(element, "rfd:tagTypeName")) {
          strcpy(tmpTagType->tagTypeName, textinfo);
        } else if (!strcmp(element, "rfd:tagManufacturerName")) {
          strcpy(tmpTagType->tagManufacturerName, textinfo);
        } else if (!strcmp(element, "rfd:tagPageSize")) {
          sscanf(textinfo,"%d",&(tmpTagType->pageSize));
        } else if (!strcmp(element, "rfd:tagMemSize")) {
          sscanf(textinfo,"%X",&(tmpTagType->memSize));
        }
      }  
    }
  }
}

static void XMLCALL end(void *data, const char *el) {
  depth--;
}

int readTagTypes(struct RFIDTagType **tagTypes) {

  FILE *fp;
  int len;
  int done;
  int i;

  for (i=0; i<100; i++)
    tagTypes[i] = NULL;

  idx = 0;

  tmpTagTypes = tagTypes;

  XML_Parser p = XML_ParserCreate(NULL);

  if (!p) {
    fprintf(stderr, "Couldn't allocate memory for parser\n");
    return;
  }

  XML_SetElementHandler(p, start, end);
  XML_SetCharacterDataHandler(p, content);

  if ((fp=fopen("rfd_types.xml","r")) == NULL) {
    fprintf(stderr, "Error opening file rfd_types.xml\n");
    return;
  }

  len = fread(buff, 1, BUFFSIZE, fp);

  if (ferror(fp)) {
    fprintf(stderr, "Read error\n");
    return;
  }

  fclose(fp);

  if (XML_Parse(p, buff, len, done) == XML_STATUS_ERROR) {
    fprintf(stderr, "Parse error at line %d:\n%s\n", XML_GetCurrentLineNumber(p), 
      XML_ErrorString(XML_GetErrorCode(p)));
    return;
  }

  return idx;
}

int getTagType(char *id, struct RFIDTagType **tagTypes) {

  int idx = 0;

  while (tagTypes[idx] != NULL) {

    int i;
    int match = TRUE;

    for (i=0; i<strlen(tagTypes[idx]->tagTypeID); i++) {
      if (tagTypes[idx]->tagTypeID[i] != '?') {
        if (id[i] != tagTypes[idx]->tagTypeID[i]) {
          match = FALSE;
        }
      }
    }    

    if (match) {
      return idx;
    }

    idx++;
  }

  return -1;
}

