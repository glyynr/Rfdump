/**************************************************************************
*                                                                         *
* RFDump                                                                  * 
* Copyright (c) 2005 DN-Systems GmbH                                      *
*                                                                         *
***************************************************************************/

struct RFIDTagType {
   char tagTypeID[255];
   char tagTypeName[255];
   char tagManufacturerName[255];
   int memSize;
   int pageSize;
};

int readTagTypes(struct RFIDTagType **tagTypes);

int getTagType(char *id, struct RFIDTagType **tagTypes);
