/**************************************************************************
*                                                                         *
* RFDump                                                                  * 
* Copyright (c) 2005 DN-Systems GmbH                                      *
*                                                                         *
***************************************************************************/

#include "rfid.h"

void xmlWriteTag(struct RFIDTag *tag);
void xmlReadTag(struct RFIDTag *tag);
