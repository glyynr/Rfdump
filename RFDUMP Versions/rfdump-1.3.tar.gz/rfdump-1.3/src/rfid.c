/**************************************************************************
*                                                                         *
* RFDump                                                                  * 
* Copyright (c) 2005 DN-Systems GmbH                                      *
*                                                                         *
***************************************************************************/

#include <termios.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/signal.h>
#include <sys/types.h>

#include "rfid.h"

#define TRUE 1
#define FALSE 0

/* RFID API */

int rfidConnectReader(char *readerdevice) {

   struct termios oldtio, newtio;       //place for old and new port settings for serial port
   struct sigaction saio;               //definition of signal action

   /* open the device (com port) to be non-blocking (read will return immediately) */

   int fd;
   fd = open(readerdevice, O_RDWR | O_NOCTTY | O_NONBLOCK);

   if (fd < 0)
   {
      fprintf(stderr, "Unable to connect to card reader device at %s\n", readerdevice);
      exit(1);
   }

   /* install the serial handler before making the device asynchronous */

   //saio.sa_handler = signal_handler_IO;
   //sigemptyset(&saio.sa_mask); //saio.sa_mask = 0;
   //saio.sa_flags = 0;
   //saio.sa_restorer = NULL;
   //sigaction(SIGIO,&saio,NULL);

   /* allow the process to receive SIGIO */

   //fcntl(fd, F_SETOWN, getpid());

   /* Make the file descriptor asynchronous (the manual page says only */
   /* O_APPEND and O_NONBLOCK, will work with F_SETFL...) */

   //fcntl(fd, F_SETFL, FASYNC);

   tcgetattr(fd,&oldtio); //save current port settings 

   /* set new port settings for canonical input processing */

   newtio.c_cflag = BAUDRATE | CRTSCTS | DATABITS | STOPBITS | PARITYON | PARITY | CLOCAL | CREAD;
   newtio.c_iflag = IGNPAR;
   newtio.c_oflag = 0;
   newtio.c_lflag = 0; //ICANON;
   newtio.c_cc[VMIN]=1;
   newtio.c_cc[VTIME]=0;
   tcflush(fd, TCIFLUSH);
   tcsetattr(fd,TCSANOW,&newtio);

   return fd;
}

/* called when data availabe on card reader */

//void signal_handler_IO (int status)
//{
//  printf("RUNNING IO HANDLER\n");
//}

void rfidInitTag(struct RFIDTag *tag) {

  int i; 

  tag->tagID[0] = '\0';
  tag->tagTypeName[0] = '\0';
  tag->tagManufacturerName[0] = '\0';

  for (i=0; i<0xFF; i++)  
    tag->mem[i] = NULL;
}

void rfidReadAllPages(int fd, struct RFIDTag *tag) {

  char page[255];
  char pageNo[255];
  int adr;

  for (adr=0; adr<0xFF; adr++) {

    if (tag->mem[adr] != NULL)
      free(tag->mem[adr]);

    tag->mem[adr] = NULL;
  }

  adr = 0;

  while (adr <= tag->memSize) {

    sprintf(pageNo,"%02x",adr);
    rfidReadPage(fd, pageNo, page);

    if (!(strlen(page)==1 && page[0]==RFID_ERR_GENERAL_FAILURE)) {
      tag->mem[adr] = (char*)malloc(strlen(page)+1);
      strcpy(tag->mem[adr], page);
    } else {
      tag->mem[adr] = (char*)malloc(strlen("--------")+1);
      strcpy(tag->mem[adr], "--------");
    }

    adr ++;
  }
}

void rfidWriteAllPages(int fd, struct RFIDTag *tag) {

  char pageNo[255];
  int adr = 0;

  while (adr <= tag->memSize) {

    if (tag->mem[adr] != NULL) {
      sprintf(pageNo,"%02x",adr);
      rfidWritePage(fd, pageNo, tag->mem[adr]);
    }

    adr ++;
  }
}

int rfidIncrementCookie(int fd, struct RFIDTag *tag) {

  char page[255];
  char pageNo[255];

  /* read counter */

  sprintf(pageNo, "%02x", tag->memSize-1);
  rfidReadPage(fd, pageNo, page);

  /* increment counter */

  int counter = 0;
  sscanf(page,"%d",&counter);
  counter++;
  sprintf(page,"%08d",counter);

  /* write counter */

  strcpy(tag->mem[tag->memSize-1], page);
  rfidWritePage(fd, pageNo, page);

  return counter;
}

void rfidInitCookie(int fd, struct RFIDTag *tag, char *cookieID) {

  char page[255];
  char pageNo[255];

  sprintf(pageNo,"%02x", tag->memSize-2);
  rfidWritePage(fd, pageNo, cookieID);          

  sprintf(pageNo,"%02x", tag->memSize-1);
  rfidWritePage(fd, pageNo, "00000000");          
}

void rfidReadLine(int fd, char *result) {

  char inputChar;
  char buf[255];
  int pos = 0;
  int numRead = 0;
//  char *result;
  int finished = FALSE;

  buf[0] = '\0';

  do
  {
    numRead = read(fd,&inputChar,1);

    if (numRead == 1) 
    {
      buf[pos] = inputChar;
      pos++;
      buf[pos] = '\0';

      if ((int)buf[pos-1] == 0x0A && (int)buf[pos-2] == 0x0D) {
        buf[pos-2] = '\0';
        finished = TRUE;
      }
    }

  } while (!finished);

  //result = (char*)malloc(sizeof(buf)+2);
  strcpy(result, buf);
  //return result;
}

void rfidReadPage(int fd, char *pageNo, char *page) {

  char rfidCmd[255];
  rfidCmd[0] = '\0';

  strcat(rfidCmd, RFID_CMD_READ_PAGE);
  strcat(rfidCmd, pageNo);

  /* write command to card reader */

  write(fd, rfidCmd, strlen(rfidCmd));

  /* read response */

  rfidReadLine(fd, page);
}

void rfidWritePage(int fd, char *pageNo, char *page) {

  char rfidCmd[255];
  rfidCmd[0] = '\0';

  strcat(rfidCmd, RFID_CMD_WRITE_PAGE);
  strcat(rfidCmd, pageNo);
  strcat(rfidCmd, page);

  printf("WRITE:%s\n", rfidCmd);

  write(fd, rfidCmd, strlen(rfidCmd));
  rfidReadLine(fd, rfidCmd);
}

void rfidReset(int fd) {

  char rfidCmd[255];
  rfidCmd[0] = '\0';

  strcat(rfidCmd, RFID_CMD_RESET);

  printf("WRITE:%s\n", rfidCmd);

  write(fd, rfidCmd, strlen(rfidCmd));
  rfidReadLine(fd, rfidCmd);
}

void rfidGetTagID(char *select, char *tagID) {
   strcpy(tagID, select+1);
}
