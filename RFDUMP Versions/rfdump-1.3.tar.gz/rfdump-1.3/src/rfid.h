/**************************************************************************
*                                                                         *
* RFDump                                                                  * 
* Copyright (c) 2005 DN-Systems GmbH                                      *
*                                                                         *
***************************************************************************/

/* configuration settings for ACG reader */

#define BAUDRATE B9600
#define DATABITS CS8
#define STOPBITS 0
#define PARITYON 0
#define PARITY 0

struct RFIDTag {
   char tagID[255];
   char tagTypeName[255];
   char tagManufacturerName[255];
   int memSize;
   int pageSize;
   char * mem[256];
};

/* RFID API constants */

#define RFID_CMD_RESET "x"
#define RFID_CMD_VERSION "v"
#define RFID_CMD_SELECT "s"
#define RFID_CMD_READ_PAGE "r"
#define RFID_CMD_WRITE_PAGE "w"

#define RFID_ERR_UNKNOWN_CMD '?'
#define RFID_ERR_GENERAL_FAILURE 'F'
#define RFID_ERR_INVALID_DATA 'I'
#define RFID_ERR_NO_TAG 'N'
#define RFID_ERR_WRITE_FAILURE 'U'
#define RFID_ERR_PAGE_LOCKED 'L'

#define RFID_MSG_UNKNOWN_CMD "Unknown Command"
#define RFID_MSG_GENERAL_FAILURE "General Failure"
#define RFID_MSG_INVALID_DATA "Invalid Data"
#define RFID_MSG_NO_TAG "No Tag"
#define RFID_MSG_WRITE_FAILURE "Write Failure"
#define RFID_MSG_PAGE_LOCKED "Lock Failure"

#define RFID_BLANK ""
#define RFID_COOKIE_ID "DEADFACE"

/* RFID API */

int rfidConnectReader(char *readerdevice);
void rfidInitTag(struct RFIDTag *tag);

void rfidReadLine(int fd, char *result);
void rfidReadPage(int fd, char *pageNo, char *page);
void rfidReset(int fd);
void rfidWritePage(int fd, char *pageNo, char *page);

void rfidReadAllPages(int fd, struct RFIDTag *tag);
void rfidWriteAllPages(int fd, struct RFIDTag *tag);
int rfidGetMaxAddress(struct RFIDTag *tag);

int rfidIncrementCookie(int fd, struct RFIDTag *tag);
void rfidInitCookie(int fd, struct RFIDTag *tag, char *cookieID);

void rfidGetTagID(char *select, char *tagID);
char *rfidGetTagTypeName(char *select);
char *rfidGetTagManufacturerName(char *select);

//void signal_handler_IO (int status);


