#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <stdio.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"

#include "xml.h"

extern struct RFIDTag tag;
extern int fd;

GtkWidget *windowPreferences;
GtkWidget *windowAbout;

extern int use_cookies;
extern gchar *cookie_id;

void updateGUI(int adr, gchar *new_text);

void
on_quit1_activate                      (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
  gtk_main_quit();
  exit(1);
}


void
on_copy1_activate                      (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
  xmlWriteTag(&tag);
}


void
on_paste1_activate                     (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
   int adr;
   char *blank;

   xmlReadTag(&tag);
   rfidWriteAllPages(fd, &tag);

   for (adr=0; adr<=tag.memSize; adr++) {
     if (tag.mem[adr] != NULL) {
       updateGUI(adr, tag.mem[adr]);
     } else {
       blank = (char*)malloc(strlen("--------") + 1);
       strcpy(blank, "--------");
       updateGUI(adr, blank);
     }
   }
}

void
on_view1_activate                    (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
  GtkWidget *windowClipboard;
  GtkWidget *textview;

  FILE *fp;
  int len;
  char buff[32000];

  windowClipboard = create_windowClipboard();
  gtk_widget_show(windowClipboard);

  textview = lookup_widget(GTK_WIDGET(windowClipboard), "textview");

  if ((fp=fopen("rfd.xml","r")) == NULL) {
    fprintf(stderr, "Error opening file rfd.xml\n");
    return;
  }

  len = fread(buff, 1, 32000, fp);

  if (ferror(fp)) {
    fprintf(stderr, "Read error\n");
    return;
  }

  fclose(fp);

  gtk_text_buffer_set_text(gtk_text_view_get_buffer(GTK_TEXT_VIEW(textview)), buff, -1);
}

void
on_about1_activate                     (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
  windowAbout = create_windowAbout();
  gtk_widget_show(windowAbout);
}


void
on_buttonOK_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
  GtkWidget *cbCookieActive = lookup_widget(GTK_WIDGET(windowPreferences), "cbCookieActive");
  GtkWidget *tfCookieID = lookup_widget(GTK_WIDGET(windowPreferences), "tfCookieID");

  if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(cbCookieActive))) {
    use_cookies = TRUE;
  } else {
    use_cookies = FALSE;
  }

  gchar *id = (gchar*)gtk_entry_get_text(GTK_ENTRY(tfCookieID));
  strcpy((char*)cookie_id, (char*)id);

  gtk_widget_hide(windowPreferences);
}


void
on_preferences1_activate               (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{
  windowPreferences = create_windowPreferences();

  GtkWidget *cbCookieActive = lookup_widget(GTK_WIDGET(windowPreferences), "cbCookieActive");
  GtkWidget *tfCookieID = lookup_widget(GTK_WIDGET(windowPreferences), "tfCookieID");

  if (use_cookies)
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(cbCookieActive), TRUE);

  if (cookie_id != NULL) {
    gtk_entry_set_text(GTK_ENTRY(tfCookieID), cookie_id);    
  }

  gtk_widget_show(windowPreferences);
}


void
on_btAboutOK_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
  gtk_widget_hide(windowAbout);
}


