/**************************************************************************
*                                                                         *
* RFDump                                                                  * 
* Copyright (c) 2005 DN-Systems GmbH                                      *
*                                                                         *
***************************************************************************/

#include <stdio.h>

#include "settings.h"

void getProperty(char *name, char *value) {

  FILE *cf;
  value[0] = '\0';
  char linebuf[255];

  if (strcmp(name,"DEV")) {
    return;
  }

  if ((cf = fopen("rfd.conf","r")) == NULL) {
    fprintf(stderr, "Unable to open config file rfd.conf\n");
    exit(1);
  }

  while (!feof(cf)) {
    fgets(linebuf, 255, cf);
    if (strstr(linebuf,"dev = ") != NULL) {
      strcpy(value, linebuf+6);
      value[strlen(value)-1]='\0';
    }
  }

  fclose(cf);

  if (strlen(value) == 0) {

    fprintf(stderr, "Invalid config file rfd.conf or missing reader device specification.\n");
    fprintf(stderr, "rfd.conf needs to contain a line like this one:\n");
    fprintf(stderr, "dev = /dev/ttyS1\n");
    exit(1);
  }
}
