/**************************************************************************
*                                                                         *
* RFDump                                                                  * 
* Copyright (c) 2005 DN-Systems GmbH                                      *
*                                                                         *
***************************************************************************/

#include <stdio.h>
#include <expat.h>

#include "xml.h"

#define BUFFSIZE 8192

char buff[BUFFSIZE];
int depth;
int offset;
struct RFIDTag *tmpTag;

void xmlWriteTag(struct RFIDTag *tag) {

  FILE *fp;
  int i;
  
  if ((fp=fopen("rfd.xml","w")) == NULL) {
    printf("Error opening file rfd.xml\n");
    return;
  }

  fprintf(fp, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
  fprintf(fp, "<!DOCTYPE tag SYSTEM \"rfd.dtd\">\n");
  fprintf(fp, "<rfd:tag xmlns:rfd=\"http://www.rfdump.org/rfd\">\n");
  fprintf(fp, "  <rfd:tagID>%s</rfd:tagID>\n", tag->tagID);
  fprintf(fp, "  <rfd:tagTypeName>%s</rfd:tagTypeName>\n", tag->tagTypeName);
  fprintf(fp, "  <rfd:tagManufacturerName>%s</rfd:tagManufacturerName>\n", tag->tagManufacturerName);
  fprintf(fp, "  <rfd:tagData encoding=\"HEX\">\n");

  for (i=0; i<128; i++) {
    if (tag->mem[i] != NULL)
      fprintf(fp, "    <rfd:tagDataItem offset=\"%02X\">%s</rfd:tagDataItem>\n", i, tag->mem[i]);
  }

  fprintf(fp, "  </rfd:tagData>\n");
  fprintf(fp, "</rfd:tag>\n");

  fclose(fp);
}

static void XMLCALL start(void *data, const char *el, const char **attr) {

  int i;

  //for (i = 0; i < depth; i++)
    //printf("  ");

  //printf("%s", el);

  for (i = 0; attr[i]; i += 2) {

    //printf(" %s='%s'", attr[i], attr[i+1]);

    if (!strcmp(attr[i], "offset")) {
      sscanf(attr[i+1],"%X",&offset);
      //strcpy(offset, attr[i+1]);
    }
  }

  //printf("\n");
  depth++;
}

static void XMLCALL content(void *data, const char *s, int len) {

  if (len > 0) {

    char * textinfo = malloc(len+1);
    strncpy(textinfo, s, len);
    textinfo[len] = '\0';

    // strip white spaces

    int strip = 1;
    char c;

    while (strip) {
      c = textinfo[strlen(textinfo)-1];
      if (c == ' ' || c == '\t' || c == '\n') {
        textinfo[strlen(textinfo)-1] = '\0';
      } else {
        strip = 0;
      }
    }
    
    if (strlen(textinfo)>0) {
      //printf("'%s' (%d)\n", textinfo, depth);
      if (depth==3) {
        //printf("OFFSET:%dDATA:%s", offset, textinfo);
        tmpTag->mem[offset] = (char*)malloc(strlen(textinfo)+1);
        strcpy(tmpTag->mem[offset], textinfo);
      }
    }
  }
}

static void XMLCALL end(void *data, const char *el) {
  depth--;
}

void xmlReadTag(struct RFIDTag *tag) {

  FILE *fp;
  int len;
  int done;
  int adr;

  for (adr=0; adr<0xFF; adr++) {

    if (tag->mem[adr] != NULL)
      free(tag->mem[adr]);

    tag->mem[adr] = NULL;
  }
  
  tmpTag = tag;

  XML_Parser p = XML_ParserCreate(NULL);

  if (!p) {
    fprintf(stderr, "Couldn't allocate memory for parser\n");
    return;
  }

  XML_SetElementHandler(p, start, end);
  XML_SetCharacterDataHandler(p, content);

  if ((fp=fopen("rfd.xml","r")) == NULL) {
    fprintf(stderr, "Error opening file rfd.xml\n");
    return;
  }

  len = fread(buff, 1, BUFFSIZE, fp);

  if (ferror(fp)) {
    fprintf(stderr, "Read error\n");
    return;
  }

  fclose(fp);

  if (XML_Parse(p, buff, len, done) == XML_STATUS_ERROR) {
    fprintf(stderr, "Parse error at line %d:\n%s\n", XML_GetCurrentLineNumber(p), 
      XML_ErrorString(XML_GetErrorCode(p)));
    return;
  }
}
